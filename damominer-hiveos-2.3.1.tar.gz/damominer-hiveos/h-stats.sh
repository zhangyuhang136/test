#!/usr/bin/env bash

khs=0
stats=
algo='aleo'

source h-manifest.conf
miner_name=$CUSTOM_NAME
miner_version=$CUSTOM_VERSION


gpus=`curl -s --connect-timeout 5 http://127.0.0.1:5001/gpu`

if [[ $? -ne 0 || -z $gpus ]]; then
  echo -e "Failed to get gpus info from 127.0.0.1:5001/gpu"
else
  data=`echo "$gpus" | jq -cr '.data'`
  readarray -t tmp_arr < <(echo "$data" | jq -cr '.uptime, [.gpus[].proof], ([.gpus[].proof]|add/1000), [.gpus[].fan], [.gpus[].ctmp], [.gpus[].id] ' 2>/dev/null)
  version="$miner_version"
  uptime="${tmp_arr[0]/s/}"
  unit="hs"
  hs="${tmp_arr[1]}" 
  khs="${tmp_arr[2]}"
  
  bus_numbers="${tmp_arr[5]}"
  temp="${tmp_arr[4]}"
  fan="${tmp_arr[3]}"


  # Example of `$stats` var
  #{ 
	#"hs": [123, 223.3], //array of hashes
	#"hs_units": "khs", //Optional: units that are uses for hashes array, "hs", "khs", "mhs", ... Default "khs".   
	#"temp": [60, 63], //array of miner temps
	#"fan": [80, 100], //array of miner fans
	#"uptime": 12313232, //seconds elapsed from miner stats
	#"ver": "1.2.3.4-beta", //miner version currently run, parsed from it's api or manifest 
	#"ar": [123, 3], //Optional: acceped, rejected shares 
	#"algo": "customalgo", //Optional: algo used by miner, should one of the exiting in Hive
	#"bus_numbers": [0, 1, 12, 13] //Pci buses array in decimal format. E.g. 0a:00.0 is 10
  #}

  stats=$(jq -nc --arg uptime "$uptime" \
                 --arg algo "$algo" \
                 --arg hs_units "$unit" \
                 --arg khs "$khs" \
                 --arg ver "$version" \
                 --argjson fan "$fan" \
                 --argjson temp "$temp" \
                 --argjson bus_numbers "$bus_numbers" \
                 --argjson hs "$hs" \
                 '{$hs, $hs_units, $temp, $fan, "uptime":$uptime|tonumber|floor, $ver, $algo, $bus_numbers, "total_khs": $khs|tonumber}')

  #echo "$stats"

fi
