#!/usr/bin/env bash

#set -ex

. colors

khs=0
stats=
algo='aleo'

source h-manifest.conf
miner_name=$CUSTOM_NAME
miner_version=$CUSTOM_VERSION


#gpus='{"code":200,"data":{"gpus":[{"cclk":1605,"ctmp":69,"device":"3090","fan":73,"gmclk":9501,"id":0,"inval":0,"mtmp":"93","power":342,"proof":3362.85,"statle":0,"valid":16},{"cclk":1605,"ctmp":77,"device":"90HX","fan":98,"gmclk":9501,"id":1,"inval":0,"mtmp":"93","power":241,"proof":1981.225,"statle":0,"valid":7}],"uptime":286}}'

gpus=`curl -s --connect-timeout 5 http://127.0.0.1:5001/gpu`

if [[ $? -ne 0 || -z $gpus ]]; then
  echo -e "${YELLOW}Failed to read stat from 127.0.0.1:5001/gpu"
else
  data=`echo "$gpus" | jq -cr '.data'`
  readarray -t arr < <(echo "$data" | jq -cr '.uptime, [.gpus[].proof], ([.gpus[].proof]|add/1000), [.gpus[].fan], [.gpus[].ctmp], [.gpus[].id] ' 2>/dev/null)
  version="$miner_version"
  uptime="${arr[0]/s/}"
  units="ps"
  hs_units="${units/ps/hs}" # ps -> hs
  air="[]"
  hs="${arr[1]}"
  
  #khs=`echo "$hs" | jq -r 'add/1000'`
  khs="${arr[2]}"
  
  bus_numbers="${arr[5]}"
  temp="${arr[4]}"
  fan="${arr[3]}"


  stats=$(jq -nc --arg uptime "$uptime" \
                 --arg algo "$algo" \
                 --arg hs_units "$hs_units" \
                 --arg khs "$khs" \
                 --arg ver "$version" \
                 --argjson temp "$temp" \
                 --argjson fan "$fan" \
                 --argjson bus_numbers "$bus_numbers" \
                 --argjson hs "$hs" \
                 --argjson ar "$air" \
                 '{"total_khs": $khs|tonumber, $hs, $hs_units, "uptime":$uptime|tonumber|floor, $algo, $ar, $temp, $fan, $bus_numbers, $ver}')

  #echo "#debug: $stats"
fi
